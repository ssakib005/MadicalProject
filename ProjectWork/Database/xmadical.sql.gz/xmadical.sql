-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2017 at 05:57 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xmadical`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(225) NOT NULL,
  `p_pin` int(20) NOT NULL,
  `d_pin` tinytext NOT NULL,
  `d_name` tinytext NOT NULL,
  `p_serial` int(20) NOT NULL,
  `appo_date` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `p_pin`, `d_pin`, `d_name`, `p_serial`, `appo_date`) VALUES
(1, 1234, 'kamal', 'Kamal', 1, '2017-11-16');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_list`
--

CREATE TABLE `doctor_list` (
  `d_id` int(255) NOT NULL,
  `d_name` varchar(30) NOT NULL,
  `d_degree` text NOT NULL,
  `d_catagory` varchar(30) NOT NULL,
  `d_detail` varchar(30) NOT NULL,
  `d_specialist` varchar(30) NOT NULL,
  `d_email` tinytext NOT NULL,
  `d_phone` int(30) NOT NULL,
  `d_pin` tinytext NOT NULL,
  `d_pass` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_list`
--

INSERT INTO `doctor_list` (`d_id`, `d_name`, `d_degree`, `d_catagory`, `d_detail`, `d_specialist`, `d_email`, `d_phone`, `d_pin`, `d_pass`) VALUES
(1, 'Kamal', '(FCPS(OBS & GYNAE);FGES)', 'medicine', 'Professor', 'Serjon', 'kamal@gmail.com', 1944102869, 'kamal', 'kamal123'),
(2, 'Dr. Korim', '(FCPS(OBS & GYNAE);FGES)', 'gynecologist', 'Chief Consultant(Gynse)', 'Gynecologist Laparoscopic Sur.', 'korim@gmail.com', 2147483647, 'korim', 'korim123');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `id` int(50) NOT NULL,
  `p_pin` int(30) NOT NULL,
  `d_pin` tinytext,
  `medicine` tinytext,
  `time` text NOT NULL,
  `day` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `p_pin`, `d_pin`, `medicine`, `time`, `day`, `date`) VALUES
(68, 1234, 'korim', 'Monas', '1+1+1', '4', ''),
(78, 1234, 'kamal', 'Maxpro', '0+1+0', '3', '2017/12/01');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `age` tinytext,
  `gender` tinytext,
  `address` tinytext,
  `email` tinytext,
  `mobile` int(12) DEFAULT NULL,
  `pin` int(30) DEFAULT NULL,
  `password` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `name`, `age`, `gender`, `address`, `email`, `mobile`, `pin`, `password`) VALUES
(1, 'Sakib', '24', 'male', '11/5 A mirbug', 'ssakib@gmail.com', 1944102869, 1234, '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_list`
--
ALTER TABLE `doctor_list`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `doctor_list`
--
ALTER TABLE `doctor_list`
  MODIFY `d_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
